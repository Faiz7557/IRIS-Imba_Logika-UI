# Spesifikasi dan wireframe yang dibangun

Pengguna utama: analis kuota pusat. Pengguna sekunder: dinas dan admin agregat. K1–K4 memakai default Plan A dalam mandat eksekusi pengguna. Produk adalah prototype kuota agregat, tanpa pemeringkatan siswa.

Palet: perlindungan #086558, analisis #235A91, teks #172E3A, perhatian #775315, latar #F3F6F8, garis #D6E0E5. Segoe UI/Arial lokal. Logo berwarna dan satu warna tersedia sebagai SVG. Kategori petak mempunyai simbol I–IV, kurva nasional memakai garis putus-putus, dan bar mempunyai label angka. Rasio pasangan teks utama 5,00–14,11:1; bukti di verification/contrast_report.json.

Wireframe dasar desktop:

```text
+---------------------+-----------------------------------------------------+
| EduShield            | DATA SIMULASI dan penjelasan batas angka             |
| Pemilih ruang kerja  | Breadcrumb / versi / reset                           |
|                      +-----------------------------------------------------+
| Navigasi sesuai peran| Judul keputusan dan kode layar                       |
|                      | Panel utama          | Penjelasan / pembanding       |
|                      |                                                      |
| Dokumentasi          | Tabel wilayah atau aksi keputusan                    |
|                      +-----------------------------------------------------+
|                      | Model, versi data, seed, hash                         |
+---------------------+-----------------------------------------------------+
```

| Layar | Area keputusan utama | Area penjelasan / aksi |
|---|---|---|
| A1 | Pagu, proksi rentan, manfaat seed 0 | Cakupan gugus, λ, median MC terpisah |
| A2 | Peta petak dan filter | 20 laju tertinggi dan rentang stabilitas |
| A3 | Prediksi dan kuota wilayah | Kontribusi logit, kurva marjinal dan batas |
| A4 | Penggeser pagu, α, β, κ, biaya | Bejana cakupan, tabel 514 hasil, galat input |
| A5 | Perbandingan siswa tertahan | Pemilih proyeksi/evaluasi dan median MC |
| A6 | Heatmap ketidakcocokan asumsi | Ukuran prediksi dan arti gain |
| A7 | Lintasan kuota lima tahun | Manfaat evaluasi dan cakupan per gugus |
| A8 | Tabel usulan kuota kontinu | Catatan peninjau, cetak, CSV, JSON |
| B1 | Merata, KKT dan transisi daerah | Alasan umum dan tautan pemeriksaan |
| B2 | Faktor model wilayah | Kurva marjinal dan daerah serupa |
| B3 | Mockup formulir koreksi | Bukti dan pratinjau tanpa pengiriman |
| B4 | Mockup format laporan agregat | Pemilihan berkas tanpa unggah |
| C1 | Mockup validasi paket | Cakupan 514/38, batas validasi produksi |
| C2 | Mockup kalibrasi | Residual Supiori, κ dan agenda semester |
| C3 | Mockup audit | Antrean contoh dan kebutuhan log override |
| L1 | Identitas visual | Logo, tagline, palet, tipografi |
| L2 | Arsitektur empat lapis | Kontrak paket dan hash |
| L3 | Rencana pilot | Tahapan dan indikator yang belum tercapai |

Pada 390 px, navigasi menjadi baris mendatar dan panel menjadi satu kolom. Tabel tetap dapat digeser tanpa membuat seluruh halaman melebar. Fokus papan ketik terlihat; tautan lewati navigasi menuju main. Mockup produksi selalu dibedakan dari aksi yang benar-benar bekerja.
