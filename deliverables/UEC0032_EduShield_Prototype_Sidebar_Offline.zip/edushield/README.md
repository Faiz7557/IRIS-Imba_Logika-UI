# EduShield prototype · sidebar dan antarmuka sistem

Buka `app/index.html` langsung di Chrome atau Edge. Tidak memerlukan internet, server, atau instalasi paket antarmuka. Data BPS lokal dipadukan dengan risiko, manfaat, dan kuota simulasi. Ini perencanaan kuota kontinu agregat, belum merupakan penetapan penerima.

## Antarmuka aktif

Sidebar berisi nama halaman tanpa kode layar, dikelompokkan menurut tugas dan ruang kerja. Pada lebar di bawah 1024 px, sidebar menjadi panel yang dapat dibuka dan ditutup, dengan pengelolaan fokus, Escape, dan latar redup. Palet memakai grafit, biru analisis, putih, dan abu terang. Tipografi memakai font sistem lokal. Transisi singkat menghormati preferensi pengurangan gerak dan transparansi.

`app/ui.js` menangani navigasi, animasi, fokus, dan region tabel. `app/app.js` berisi layar dan handler. Slider simulator mempertahankan elemen input saat hasil berubah sehingga drag pointer tetap tersambung. Solver menghentikan iterasi ketika batas pencarian tidak lagi berubah pada presisi floating point; hasilnya identik dengan versi sebelumnya pada delapan skenario pembanding.

Audit desain dan kurasi seluruh 18 layar: `AUDIT_DESAIN_DAN_KONTEN.md`. Spesifikasi aktif: `DESIGN.md`. Audit Onda sebelumnya merupakan catatan historis.

## Verifikasi

```powershell
node edushield/test_app.cjs
node edushield/test_apple.cjs
```

Uji browser memerlukan Node.js, Chrome, dan Playwright (paket Node atau paket Python yang telah terpasang). Laporan, screenshot desktop/mobile, dan PDF ada di `verification/apple/`. Uji meliputi 18 rute pada enam lebar, drag slider, navigasi, fokus, formulir pratinjau, hasil ekspor, mode cetak, teks diperbesar, serta pengurangan gerak.

Chrome di host pengujian dapat membatalkan unduhan Blob. Hasil unduhan native dicatat apa adanya dalam report.json; isi CSV/JSON juga diperiksa melalui Blob yang dihasilkan handler asli.

## Data dan reproduksi riset

```powershell
python edushield/edushield.py --export
python edushield/test_kkt.py
```

Ekspor data memerlukan numpy, pandas, scipy, statsmodels, dan scikit-learn. Riset penuh memerlukan lightgbm. Perintah riset/ekspor dapat menulis ulang hasil dan paket data; tidak diperlukan untuk membuka prototype atau mengganti antarmuka. `export_app.py` membangun paket BPS lokal dan outcome seed 0. `app_data.sha256` mengidentifikasi JSON sumber.

## Batas prototype

A1–A5, A7–A8, B1–B2 interaktif. A6 memakai eksperimen tersimpan. B3–B4 dan C1–C3 adalah pratinjau tanpa unggahan, autentikasi, atau layanan server. L1–L3 berisi identitas, arsitektur, dan rencana uji coba. Rute internal dipertahankan untuk tautan lama, sementara kodenya dihilangkan dari label antarmuka.

Petak risiko bukan peta geografis. Pengelompokan 38 provinsi mengikuti berkas sumber lokal, bukan verifikasi batas administratif terkini. Rentang antar-lipatan adalah rentang stabilitas, bukan interval prediksi atau kepercayaan. κ=1,74 tetap asumsi kerja yang membutuhkan verifikasi. Populasi rentan adalah proksi, bukan daftar siswa atau penerima terdaftar. Anggaran simulator mengikuti biaya skenario aktif; eksperimen referensi dapat memakai ketentuan pagu yang berbeda.

## Referensi dan cadangan

Template Onda awal tersimpan di `reference/design-studio/`. Lisensi dan kredit historis disertakan di `app/TEMPLATE_LICENSE.txt` dan `app/TEMPLATE_CREDITS.md`. Cadangan sebelum perombakan ini ada di `verification/before-apple/`; cadangan versi sebelumnya ada di `verification/before-onda/`. Paket distribusi terbaru: `../deliverables/UEC0032_EduShield_Prototype_Sidebar_Offline.zip`.
