import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent/'figures'
OUT.mkdir(exist_ok=True)
D=json.loads((ROOT/'edushield/app/app_data.json').read_text(encoding='utf8'))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold'})
GREEN,BLUE='#086558','#235a91'
def save(fig,name):
 fig.text(.99,.005,'DATA SIMULASI',ha='right',fontsize=8,color='#775315')
 fig.savefig(OUT/(name+'.png'),dpi=300,bbox_inches='tight');plt.close(fig)

def build():
 k=D['kab'];s=D['nasional']
 fig,ax=plt.subplots(1,2,figsize=(7.1,2.45),layout='constrained')
 ax[0].hist([d['p0'] for d in k],bins=25,color=BLUE);ax[0].set(xlabel='Kemiskinan BPS 2025 (%)',ylabel='Jumlah wilayah',title='Kovariat nyata')
 ax[1].hist([100*d['r_sim'] for d in k],bins=25,color=GREEN);ax[1].set(xlabel='Laju benar simulasi (%)',title='Outcome dibangkitkan, bukan diamati')
 save(fig,'data')
 fig,ax=plt.subplots(figsize=(6.7,2.5),layout='constrained')
 ax.scatter([100*d['r_sim'] for d in k],[100*d['r_hat'] for d in k],s=12,alpha=.6,color=GREEN)
 ax.plot([0,40],[0,40],ls='--',color='#555');ax.set(xlabel='Laju benar simulasi (%)',ylabel='Prediksi OOF (%)',xlim=(0,40),ylim=(0,40))
 sup=next(d for d in k if d['nama']=='Supiori');ax.annotate('Supiori: risiko ekstrem diremehkan',(100*sup['r_sim'],100*sup['r_hat']),xytext=(10,31),arrowprops={'arrowstyle':'->'},fontsize=8)
 save(fig,'prediction')
 fig,ax=plt.subplots(figsize=(6.7,2.45),layout='constrained')
 mc=s['mc_schemes']; names=list(mc); y=np.arange(len(names));v=np.array([mc[n]['median'] for n in names]);lo=np.array([mc[n]['p5'] for n in names]);hi=np.array([mc[n]['p95'] for n in names]);ax.barh(y,v,color=[BLUE]*4+[GREEN]);ax.errorbar(v,y,xerr=[v-lo,hi-v],fmt='none',ecolor='#172e3a',capsize=3);ax.set(yticks=y,yticklabels=['Merata','Kemiskinan','Greedy','Proporsional','KKT'],xlabel='Keunggulan atas merata (%), median dan P5–P95');ax.invert_yaxis();save(fig,'schemes')
 fig,ax=plt.subplots(figsize=(6.7,2.3),layout='constrained')
 ts=['exp k=0.8','exp k=1.74','exp k=3.0','pangkat (gamma=0,5)','logaritmik','exp kappa_i heterogen'];ks=['0.8','1.74','3.0'];a=np.array([[s['mc_regret'][f'KKT k_opt={ko}|{t}']['median'] for t in ts] for ko in ks]);ax.imshow(a,cmap='YlGnBu',vmin=-1,vmax=15,aspect='auto');ax.set(xticks=range(6),xticklabels=['exp 0,8','exp 1,74','exp 3','akar','log','κ heterogen'],yticks=range(3),yticklabels=ks,xlabel='Kurva evaluasi',ylabel='κ optimasi')
 for i in range(3):
  for j in range(6):ax.text(j,i,f'{a[i,j]:.2f}%',ha='center',va='center',color='white' if a[i,j]>9 else '#172e3a',fontsize=8)
 save(fig,'robustness')
 fig,ax=plt.subplots(figsize=(6.7,2.2),layout='constrained')
 for n in ['Sumba Tengah','Nduga','Kota Yogyakarta','Kota Surabaya','Supiori']:
  d=next(d for d in k if d['nama']==n);v=d['V'];ax.plot(range(6),[100*d['x']['merata']/v]+[100*x/v for x in d['hh']],marker='o',ms=3,label=n)
 ax.set(xlabel='Tahun transisi',ylabel='Cakupan kuota (%)',ylim=(15,100));ax.legend(fontsize=7,ncol=2,loc='upper right');save(fig,'transition')
 fig,ax=plt.subplots(figsize=(6.7,2.4),layout='constrained');t=np.linspace(.2,.95,100)
 for n in ['Sumba Tengah','Nduga','Kota Yogyakarta','Kota Surabaya','Supiori']:
  d=next(d for d in k if d['nama']==n);ax.plot(t*100,1.74*d['r_hat']*np.exp(-1.74*t)/1.8*1000,label=n)
 ax.axhline(s['harga_bayangan_per_miliar']['1.74'],ls='--',color='#172e3a',label='λ* nasional');ax.set(xlabel='Cakupan kuota (%)',ylabel='Manfaat marjinal / Rp1 miliar');ax.legend(fontsize=7,ncol=2);save(fig,'marginal')

if __name__=='__main__':build()
