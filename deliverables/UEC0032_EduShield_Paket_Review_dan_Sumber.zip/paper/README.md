# EduShield — esai dan lampiran yang dapat diregenerasi

Edit melalui `script/`, kemudian jalankan `python paper/script/build.py` dari folder induk. File di `output/` adalah hasil generate. Nama berkas memakai UEC0032 dan EduShield sebagai nama proyek sementara; nama tim dan institusi belum diberikan, sehingga hasil tetap DRAF.

## Peta sumber

- `script/content_compact.md`: badan esai yang dipakai PDF/DOCX, dengan placeholder angka dan kunci sitasi.
- `script/content.md` dan `content_detailed.md`: bahan uraian panjang sebelum penyuntingan batas halaman; bukan sumber build akhir.
- `script/build.py`: template, cover, tabel, OMML, LM1–LM6, lampiran screenshot, pemeriksaan angka, dan konversi PDF.
- `script/figures.py`: enam grafik matematika/data 300 dpi; gambar keenam badan diambil dari screenshot simulator.
- `script/references.py`: 15 sumber primer/laman penerbit/penulis, beserta URL.
- `script/source_audit.md`: status tiap klaim R1–R15 dan keterbatasan akses sumber.
- `../edushield/angka.json`: registri 21 angka dinamis dan format tampilnya.
- `output/qa_report.json`: hitungan halaman PDF aktual dan pemeriksaan.

## Reproduksi

Dependensi tersedia lokal: numpy, pandas, scipy, statsmodels, scikit-learn, matplotlib, pillow, python-docx, pymupdf, pywin32. Python Playwright dan Chrome dibutuhkan untuk tangkapan layar. LightGBM diperlukan hanya untuk mengulang seluruh penelitian.

```powershell
python edushield/edushield.py --export
node edushield/test_app.cjs
python edushield/capture_app.py
python paper/script/build.py
```

PDF dikonversi dari DOCX yang sama melalui aplikasi kompatibel Word yang terdaftar di Windows. Pada komputer ini registrasi Word.Application menunjuk WPS, sehingga build membuka satu aplikasi tersembunyi per dokumen dan menutupnya sesudah konversi. Tidak mengubah registrasi sistem. Di mesin yang terdaftar Microsoft Word, jalur otomasi yang sama dapat digunakan. Perubahan aplikasi/font dapat menggeser halaman; jalankan QA kembali.

## Keputusan dokumen

Bahasa Indonesia formal dengan “kami”, IEEE menurut urutan kemunculan, A4, margin 4/3/3/3 cm, Times New Roman 12, spasi 1,5; pustaka spasi 1. Bab dimulai di halaman baru. Bagan/gambar dibuat dari JSON atau screenshot aplikasi yang sama. Dua persamaan badan memakai OMML. Semua screen lampiran mempunyai satu anotasi bernomor dan keterangan masalah/tujuan.

Cover sudah berisi UEC0032 dan tiga nama/NIM. Nama tim, institusi dan kota tetap placeholder; jangan menebaknya dari NIM. Lembar orisinalitas dan tanda tangan tidak dipalsukan. Turnitin belum dijalankan. Status publikasi/submisi tetap belum dikirim.

## Membaca hasil

`UEC0032_EduShield_Esai_DRAF.pdf/.docx` berisi cover, badan, pustaka, matematika, dan prototype. `UEC0032_EduShield_Lampiran_Prototype.pdf/.docx` adalah lampiran prototype terpisah. `esai_terbaca.md` memudahkan peninjauan isi tanpa Office. `preview_*.png` adalah render per halaman, bukan dokumen submisi.

Jangan menyebut κ terkalibrasi empiris sebelum tabel artikel diperiksa. Jangan mengganti median 30 ulangan dengan seed 0 atau sebaliknya. Jangan menyebut rentang antar-lipatan sebagai interval prediksi. Penjelasan lengkap berada di `../ANALISIS_DAN_EKSEKUSI_EduShield.md` dan `script/source_audit.md`.
