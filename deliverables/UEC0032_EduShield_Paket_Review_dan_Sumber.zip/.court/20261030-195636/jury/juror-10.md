VOTE: NOT GUILTY
REASON: Saya bersedia membiayai demonstrasi ini karena optimisasi dan implementasinya sudah dapat diperagakan, sedangkan keterbatasan bukti dinyatakan sehingga investasi tidak bergantung pada janji dampak kebijakan nyata.
DECIDING FACT: Perkara secara eksplisit membatasi EduShield pada demonstrasi metode dengan outcome sepenuhnya simulasi, bukan model yang diklaim terkalibrasi empiris.
WOULD FLIP IF: Draf mengusulkan penerapan kuota PIP nyata dengan V yang sama sebelum menguji sensitivitas kesalahan kebutuhan antarwilayah.
