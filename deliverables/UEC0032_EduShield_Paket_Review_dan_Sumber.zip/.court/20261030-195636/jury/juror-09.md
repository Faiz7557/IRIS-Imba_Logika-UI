VOTE: NOT GUILTY
REASON: Sebagai orang tua, saya dapat menerima demonstrasi bersyarat yang jujur tentang simulasinya karena perkara ini belum meminta keluarga mempertaruhkan bantuan nyata pada hasil tersebut.
DECIDING FACT: Draf membatasi kesimpulan pada outcome sepenuhnya simulasi dan tidak mengklaim model telah terkalibrasi empiris.
WOULD FLIP IF: Draf merekomendasikan pemakaian hasilnya untuk menetapkan kuota PIP nyata sebelum kesalahan proksi kebutuhan antarwilayah diuji.
