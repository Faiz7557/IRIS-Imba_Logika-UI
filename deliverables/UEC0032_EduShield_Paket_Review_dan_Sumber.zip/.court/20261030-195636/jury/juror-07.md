VOTE: NOT GUILTY
REASON: Sebagai pemilik usaha, saya belum akan memakai model ini untuk membagikan uang sungguhan, tetapi demonstrasi bersyarat yang berjalan dan terbuka tentang asumsi masih layak dipertahankan dalam esai.
DECIDING FACT: Perkara membatasi EduShield sebagai demonstrasi metode dengan outcome sepenuhnya simulasi, bukan sistem alokasi yang dinyatakan siap digunakan.
WOULD FLIP IF: Draf mengubah klaimnya menjadi siap menentukan kuota PIP nyata sementara sensitivitas kesalahan kebutuhan antarwilayah belum diuji.
