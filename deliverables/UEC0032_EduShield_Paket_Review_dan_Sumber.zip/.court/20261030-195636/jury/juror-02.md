VOTE: NOT GUILTY
REASON: Sebagai orang yang baru mengenalnya, saya mau memakai EduShield sebagai peragaan matematika karena batas simulasinya jelas dan hasil pembanding sederhananya diakui secara terbuka.
DECIDING FACT: Draf mengakui gain proporsional terhadap merata sebesar 7,54% melampaui KKT sebesar 7,34%, sehingga tidak menjual KKT sebagai pemenang praktis yang sudah terbukti.
WOULD FLIP IF: Draf mengklaim KKT lebih layak dipakai untuk alokasi PIP nyata tanpa pengujian kesalahan proksi kebutuhan antarwilayah.
