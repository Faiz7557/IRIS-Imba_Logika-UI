Apakah draf v2 EduShield layak dipertahankan sebagai demonstrasi metode alokasi kuota PIP untuk esai UEC LOGIKA UI 2026, setelah perbaikan putusan sebelumnya?

Peserta UEC0032 meminta analisis kedua plan dan eksekusi end-to-end, Plan A lebih dahulu. Rubrik: format 15%, inovasi 20%, urgensi 15%, tema 5%, aktualisasi 15%, data/literatur 10%, matematika 20%. Badan esai maksimum 10 halaman.

Untuk pemeriksaan bukti, baca berkas berikut di workspace ini:
- paper/output/esai_terbaca.md: isi draf dengan angka dan sitasi berurutan.
- paper/script/content.md dan references.py: sumber teks dan pustaka.
- edushield/edushield.py: DGP, GLM, skema dan eksperimen.
- edushield/results/summary.json: seluruh hasil 30 ulangan.
- edushield/verification/solver_report.json dan browser_report.json: pengujian aktual.
- edushield/app/index.html dan app.js: prototype 18 layar.
- ANALISIS_DAN_EKSEKUSI_EduShield.md: keputusan, keterbatasan, dan koreksi plan.
- .court/20261030-165340/VERDICT.md: putusan draf lama dan syarat pembebasan.

Fakta untuk konteks: kovariat lokal BPS nyata, 514 wilayah/38 provinsi, outcome sepenuhnya simulasi; rho memakai laju prediksi langsung tanpa perkalian peluang klasifikasi. Median gain KKT terhadap merata 7,3436%, proporsional 7,5369%, median manfaat/oracle 97,8241%. Seed 0 gain KKT 8,7597%, ditampilkan terpisah. Evaluasi ketidakcocokan kurva 18 sel: 17 median gain positif. Istilah mc_regret dalam JSON diakui sebagai gain, bukan regret terhadap optimum.

Hold-harmless 10% per tahun dihitung pada pagu tetap. V adalah proksi dengan asumsi 0,6 dan 0,74. κ=1,74 disebut asumsi skenario; abstrak Listiyanto–Qibthiyyah 2022 menyebut efek 2,8 persen tetapi tabel lengkap belum berhasil diakses. Tidak diklaim terkalibrasi empiris. Esai mengakui keterbatasan out-of-province, normalisasi transduktif, bias ekstrem Supiori, dan perlunya pilot temporal/kuasi-eksperimen.

Prototype interaktif lokal berlabel simulasi, tanpa daftar siswa; formulir dinas/admin mockup jelas. Solver JS cocok dengan Python pada 30/55/80% dengan toleransi <1e-6, waktu browser sekitar 5–6 ms. Kuota kontinu belum dibulatkan; pergantian peran bukan autentikasi. Tata kelola merujuk Pasal 20 dan 25 UU PDP; agregat tidak dianggap otomatis bebas risiko identifikasi ulang.

Nomor dan nama anggota tersedia. Nama tim/institusi/kota belum diberikan. Dokumen masih diberi DRAF, belum ditandatangani, belum diperiksa Turnitin, belum dikirim ke lomba. Proses format PDF masih berjalan. Nilai kasus ilmiah dan kesesuaian klaim dengan bukti; jangan menyamakan draft belum lengkap administratif dengan klaim sudah siap dikirim.
