## Charges that stuck
Tidak ada keberatan yang menggugurkan demonstrasi; tiga batas berikut paling sering muncul dalam alasan atau syarat perubahan suara:

- Kesalahan proksi kebutuhan antarwilayah belum diuji, sehingga kelayakan alokasi nyata belum terbukti (6 juror: 02, 04, 06, 07, 09, 10).
- Keunggulan praktis KKT belum terbukti, terutama dibanding proporsional dengan perlindungan setara (5 juror: 01, 03, 05, 08, 11).
- Pergantian peran tanpa autentikasi belum mendukung kesiapan operasional (1 juror: 12).

## What the defense got right
- Outcome dan manfaat dinyatakan sepenuhnya simulasi; pengakuan bahwa proporsional menghasilkan gain lebih tinggi menjaga kesimpulan sesuai bukti.
- Demonstrasi dapat diperiksa: solver browser cocok dengan Python pada tiga pagu, dengan toleransi di bawah 1e-6.

## Conditions for acquittal
Pembebasan sudah berlaku; syarat perubahan suara justru memperingatkan agar klaim tidak diperluas tanpa bukti. Minggu ini:

1. Jalankan sensitivitas V dengan kesalahan berbeda antarwilayah; bandingkan KKT, proporsional, dan merata pada kebutuhan evaluasi yang dinyatakan, lalu laporkan perubahan alokasi dan manfaat.
2. Bandingkan KKT dan proporsional dengan batas perlindungan serta transisi yang sama; tampilkan hasil berdampingan dan batasi klaim keunggulan sesuai hasilnya.
3. Periksa seluruh layar peran dan narasi esai; pastikan label simulasi serta mockup tanpa autentikasi terlihat jelas, dan hapus setiap klaim siap menentukan kuota operasional.

## The sentence
Pengadilan mempertahankan EduShield sebagai demonstrasi metode bersyarat. Lanjutkan penyempurnaan esai dengan batas klaim tetap jelas, prioritaskan pengujian kebutuhan dan pembanding setara, serta tempatkan penerapan kuota nyata sebagai pekerjaan validasi berikutnya.
