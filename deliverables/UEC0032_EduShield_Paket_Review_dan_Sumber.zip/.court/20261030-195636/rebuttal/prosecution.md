1. **Bertahan.** Simulasi yang dinyatakan terang dapat menjadi demonstrasi metode; dakwaan kami bukan bahwa dampak kausal wajib tersedia, melainkan bahwa demonstrasi belum menguji asumsi kebutuhan yang menggerakkan bobot manfaat, batas kuota, dan pagunya sekaligus.

2. **Bertahan untuk pengulangan, belum untuk ketahanan keputusan.** Tiga puluh ulangan menyingkirkan keberatan satu seed, tetapi “17 median gain positif” terhadap merata tidak mengukur kehilangan terhadap optimum kurva evaluasi maupun menunjukkan KKT lebih tahan daripada proporsional, yang median dasarnya lebih tinggi.

3. **Bertahan sebagai perbaikan matematika dan kejujuran narasi.** Namun menyatakan V sebagai asumsi tidak menguji akibat kesalahannya antarwilayah: record meminta sensitivitas V, sedangkan hasil ketahanan yang dilaporkan belum menyediakannya; ini menyangkut validitas internal demonstrasi alokasi, bukan sekadar generalisasi lapangan.

4. **Bertahan.** Kecocokan solver dan prototype yang berjalan membuktikan implementasi rumus, sementara pembulatan, autentikasi, serta administrasi bukan alasan menggugurkan demonstrasi ini; pengujian implementasi tetap tidak menguji apakah proksi kebutuhan mengarahkan rumus ke pembagian yang salah.

**Satu titik keputusan juri:** Apakah demonstrasi kuota PIP layak dipertahankan sebelum menguji sensitivitas terhadap kesalahan kebutuhan antarwilayah, ketika V menentukan tujuan dan kelayakan sekaligus? Kekosongan bukti itu harus diperbaiki melalui variasi V yang tidak sekadar mengalikan semua wilayah dengan konstanta sama, lalu membandingkan KKT, proporsional, dan merata pada kebutuhan evaluasi yang dinyatakan.
