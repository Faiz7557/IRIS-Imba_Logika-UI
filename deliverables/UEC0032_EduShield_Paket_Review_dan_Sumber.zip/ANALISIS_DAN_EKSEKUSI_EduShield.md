# Analisis mendalam dan catatan eksekusi EduShield

Tanggal: 30 Oktober 2026. Peserta: UEC0032. Urutan kerja: fondasi dan Plan A, kemudian Plan B.

## 1. Penilaian Plan A

**Keputusan:** layak dibangun sebagai demonstrasi sistem pendukung keputusan agregat. Kekuatan plan adalah hubungan masalah–tujuan–komponen, solver yang dapat diaudit, dan perlindungan transisi. Kontribusi utamanya adalah aturan keputusan yang transparan; keunggulan metode prediksi kompleks belum didukung hasil simulasi.

### Temuan yang mengubah implementasi

| Temuan | Implikasi | Keputusan implementasi |
|---|---|---|
| Belum ada realisasi putus sekolah/PIP riil | Tampilan mudah disalahartikan sebagai produk siap menetapkan penerima | Pita DATA SIMULASI pada semua layar, PDF, CSV, JSON; kuota selalu usulan |
| Seed 0 KKT +8,7597%, median 30 ulangan +7,3436% | Dua angka benar tetapi tidak saling menggantikan | Pisahkan evaluasi seed 0, proyeksi model, dan ringkasan Monte Carlo referensi |
| Persentil pembagian lipatan hanya menangkap variasi model pada outcome tetap | Istilah interval prediksi 90% tidak sah | Gunakan “rentang stabilitas antar-lipatan P5–P95”, tanpa klaim cakupan probabilistik |
| GLM dirata-ratakan pada skala probabilitas | Sigmoid jumlah kontribusi rata-rata tidak persis sama dengan rata-rata probabilitas | Kontribusi dijelaskan sebagai suku logit rata-rata, dengan intersep; bukan SHAP probabilitas |
| Pagu dan batas bisa tidak layak | Bagi-dua tetap mengeluarkan angka bila input salah | Validasi Σc·lo ≤ B ≤ Σc·hi; tolak kombinasi tidak layak |
| Biaya terpencil mengubah penyebut porsi cakupan | Risiko mencampurkan eksperimen biaya pada pagu tetap dengan pagu baru | Simulator mendefinisikan pagu dari biaya cakupan penuh skenario aktif; eksperimen pagu tetap tetap di summary penelitian |
| Kuota hasil KKT kontinu | Angka pecahan belum dapat ditetapkan sebagai penerima | Kuota pecahan diberi label; pembulatan dan pemeriksaan kelayakan menjadi tahap produksi tersendiri |
| KKT menyetarakan manfaat marjinal, bukan cakupan | Ilustrasi bejana dapat memberi intuisi keliru | Bejana menunjukkan cakupan; kurva marjinal menampilkan λ dan menjelaskan kasus lantai/interior/batas atas |
| Tabel mc_regret berisi gain terhadap merata | Bukan regret terhadap oracle atau optimum kurva evaluasi | Ganti judul tampilan menjadi keunggulan terhadap merata |
| Data lokal berisi 514 wilayah dan 38 provinsi | Cakupan data lengkap, tetapi belum memiliki batas geografis resmi berlisensi terverifikasi | Peta petak non-geografis lengkap, ID internal stabil; tidak membuat koordinat atau batas palsu |
| Pergantian peran pada situs statis bukan otorisasi | Pengguna bisa membuka seluruh layar | Jelaskan sebagai ruang kerja demo; autentikasi dan kontrol akses merupakan pekerjaan produksi |

### Spesifikasi yang dipakai

K1–K4 memakai default plan sesuai mandat eksekusi: analis pusat, dasbor desktop responsif, solver nyata dalam peramban, nama EduShield. Tidak meminta persetujuan spesifikasi ulang karena pengguna sudah meminta eksekusi end-to-end dan kemudian menegaskan “Lakukan saja sekarang”.

Identitas visual: hijau perlindungan #086558, biru analisis #235A91, teks #172E3A, amber #775315, latar #F3F6F8. Segoe UI/Arial tersedia lokal. Komponen utama adalah peta petak, kurva manfaat marjinal, dan bejana cakupan. Tidak ada ketergantungan CDN, pemasangan paket, atau server aplikasi.

Alur analis: A1 nasional → A2 radar → A3 alasan wilayah → A4 simulasi → A5 pembanding → A6 ketahanan → A7 transisi → A8 ekspor. Alur dinas B1–B2 interaktif. B3–B4 dan C1–C3 adalah mockup alur produksi dan diberi label demikian. A6 memakai hasil eksperimen tersimpan yang nyata, tidak mengarang matriks.

### Integritas matematika dan batas operasional

Solver memaksimumkan Σ Vᵢρᵢ(1−exp(−κxᵢ/Vᵢ)), dengan biaya Σcᵢxᵢ=B dan batas αVᵢ≤xᵢ≤βVᵢ. Solusi interior xᵢ=Vᵢ/κ log(κρᵢ/(λcᵢ)); clipping berlaku pada batas. Kondisi turunan kedua negatif memberi solusi unik pada parameter positif dan himpunan layak. Tidak ada faktor probabilitas klasifikasi yang mengalikan ρ.

Kuota rendah tidak selalu berarti lantai; daerah berada di lantai bila manfaat marjinalnya pada lantai berada di bawah λ. Daerah berisiko tinggi dapat berada di batas atas dan tidak memenuhi persamaan marjinal interior. Pengujian tidak boleh memaksakan persamaan interior kepada seluruh wilayah.

Hold-harmless dimulai dari merata pada pagu skenario yang sama; lantai tahun berikutnya max(αV,0,9x sebelumnya). Ini menjamin batas penurunan untuk pagu tetap. Ia belum menjawab konflik pemotongan pagu antar-tahun dengan jaminan minimum lama. Apabila pagu baru kurang dari Σc·max(αV,0,9x sebelumnya), janji transisi tidak layak dan harus dirundingkan, bukan disembunyikan solver.

### Aset dan pengujian

- `edushield/app/index.html`: aplikasi offline; buka langsung di Chrome/Edge.
- `edushield/app/app_data.json`, `app_data.sha256`, `data.js`: paket dan hash; 514 ID unik, 38 provinsi.
- `edushield/export_app.py`: 10 ulangan lipatan seed 0, kontribusi, seluruh skema dan transisi; menegaskan kesamaan r_hat dengan CSV penelitian.
- `edushield/test_app.cjs`: kesetaraan Python–JS, pagu, batas, marjinal interior, input tidak layak, dan transisi.
- `edushield/capture_app.py`: pemeriksaan peramban, 18 layar, interaksi, tampilan 390 px, screenshot, CSV, dan PDF.
- `edushield/verification/`: bukti uji mesin dan peramban; bukan sekadar daftar cek yang dicentang manual.
- `edushield/lampiran/`: 18 layar desktop, satu layar seluler, lembar usulan PDF, dan CSV.

Hasil pengujian aktual tersedia dalam JSON. Pengukuran waktu adalah pada mesin lokal ini, bukan jaminan semua perangkat kantor. Akses papan ketik dan label diperiksa; audit aksesibilitas manual menyeluruh dengan pembaca layar masih diperlukan sebelum pilot.

### Penyimpangan dari plan dan alasannya

1. SVG/CSS lokal menggantikan Chart.js/Leaflet agar dapat dibuka langsung dari file tanpa internet. Tidak mengubah solver.
2. Peta petak dipakai; peta poligon/provinsi belum disertakan karena batas berlisensi dan pencocokan ID resmi belum diverifikasi. Cakupan petak 514/514 bukan keberhasilan pencocokan geometri.
3. Formulir banding, unggah dan audit merupakan mockup; tidak membuat kesan tersambung ke layanan pemerintah.
4. Tidak mendukung override kuota manual. Ekspor mencatat skenario dan catatan peninjau. Produksi harus menambahkan log override terautentikasi jika fitur itu dibangun.
5. Publikasi publik bersifat opsional dalam plan. Paket lokal siap ditinjau tanpa perlu mengunggah data atau membuat akun layanan baru.

## 2. Penilaian Plan B

**Keputusan:** struktur esai kuat jika tesis dibatasi pada demonstrasi metode. Kekuatan terbesar adalah menghubungkan turunan KKT, ketahanan asumsi, dan produk yang benar-benar menghitung. Risiko terbesar berada pada asal angka dan klaim empiris, bukan kode antarmuka.

### Koreksi substantif

1. **κ bukan fakta terverifikasi.** Artikel Listiyanto–Qibthiyyah 2022 ditemukan pada situs jurnal. Abstrak menyebut 2,8 persen dan marginal effect, tetapi tabel teks penuh belum berhasil diakses. Sementara itu κ=1,74 diperlakukan sebagai asumsi skenario, bukan estimasi yang telah tervalidasi. Tidak mengubah hasil v2 diam-diam. Bila teks penuh mengharuskan penafsiran relatif, seluruh hasil dan paket harus diregenerasi setelah kalibrasi ulang.
2. **Pembanding proporsional wajib dipertahankan.** Median +7,5369% lebih tinggi daripada KKT +7,3436%. Menyembunyikannya mengubah kesimpulan. Nilai KKT terletak pada tujuan eksplisit, batas, λ, dan transisi; bukan klaim selalu paling unggul pada outcome benar.
3. **Validasi out-of-province belum temporal.** Outcome masih simulasi. Fitur distandardisasi pada seluruh kovariat; protokol ini bersifat transduktif dan tidak menggunakan outcome uji, tetapi bukan uji lokasi baru yang sepenuhnya induktif. Pilot harus membekukan normalisasi pada data latih dan menguji semester berikutnya.
4. **Tidak menyamakan indikator.** Laju putus sekolah di antara siswa rentan, persentase anak tidak sekolah pada umur tertentu, dan angka partisipasi sekolah memiliki penyebut berbeda. Nilai target DGP 2,5% bukan angka nasional BPS.
5. **V adalah proksi.** Faktor 0,6 dan 0,74 adalah asumsi transformasi, sedangkan p0 adalah kemiskinan penduduk, bukan prevalensi kemiskinan siswa SMA. Perlu audit ekologis dan sensitivitas V sebelum penggunaan kebijakan.
6. **Dasar hukum agregat perlu kehati-hatian.** Pasal 20 ayat (2) huruf e UU PDP memuat kepentingan umum/pelaksanaan kewenangan; itu tidak menghapus kewajiban khusus data anak pada Pasal 25 jika kelak memproses data personal. Agregasi juga perlu mencegah identifikasi ulang pada sel kecil.
7. **Dokumen bukan otomatis siap kirim.** Nama tim dan institusi belum dinyatakan pengguna; nomor peserta dan nama anggota sudah ada. Lembar orisinalitas membutuhkan tanda tangan asli dan peninjauan manusia. Turnitin tidak bisa dipastikan tanpa akses pemeriksaan.

### Sumber dan batas klaim

R5 nominal PIP terkonfirmasi pada rilis Puslapdik 7 Juli 2025: Rp1,8 juta/tahun bagi SMA/SMK; nominal awal/akhir tahun dapat setengahnya. R6 terkonfirmasi pada IHPS II 2020 BPK, Gambar 1.9, halaman cetak 140. Angka itu temuan historis TA 2018–Semester I 2020 dan bukan besaran salah sasaran tahun 2026. Perpres 3/2026 terkonfirmasi dalam rilis pemerintah; jangan mengutip pasal spesifik tanpa teks peraturan.

Angka APS 0,86%/0,54%/0,09%, ATS 19,20%, angka dasbor ATS terbaru, dan klaim 5,5 juta tidak dimasukkan sebagai angka primer terverifikasi sampai tabel atau sumber aslinya terbaca. Lebih baik menghilangkan satu grafik urgensi daripada memoles sumber sekunder seolah primer.

### Ketergantungan dan gerbang mutu

Paket data Plan A menjadi sumber bersama dengan hasil v2. Grafik, tabel, dan angka esai harus dibentuk dari JSON; angka eksternal dicatat tersendiri. Formula, DGP, asumsi κ, pembanding proporsional, dan keterbatasan dicantumkan di lampiran matematis. PDF harus dikonversi dari DOCX yang sama, bukan ditulis terpisah. Halaman badan dihitung pada PDF akhir, maksimal 10 di luar cover, pustaka, dan lampiran.

Sidang court baru tidak boleh diklaim lulus tanpa menjalankan prosedurnya. Audit internal terhadap syarat putusan dapat dikerjakan dan dilaporkan terpisah dari vonis court. Penyerahan lomba dan penandatanganan bukan efek otomatis pembuatan dokumen.

## 3. Hasil akhir dan tindak lanjut court

Court dijalankan ulang penuh pada `.court/20261030-195636/`: dua opening, dua rebuttal, 12 juri independen dan satu hakim. Putusan NOT GUILTY 12–0 berlaku untuk demonstrasi metode bersyarat, bukan penerapan kebijakan riil. Seluruh pernyataan dan putusan disimpan. Agen yang tersedia di sesi ini menjalankan peran-peran tersebut; nama persona bukan identitas manusia atau penilaian pakar eksternal.

Tiga tindak lanjut hakim ditangani: (1) sensitivitas kebutuhan V pada empat bentuk kesalahan antarwilayah; (2) perbandingan transisi KKT–proporsional dengan α, β dan batas penurunan yang sama; (3) pemeriksaan label simulasi/mockup dan ketiadaan klaim kesiapan operasional. Kode `edushield/stress_followup.py`, hasil JSON dan laporan markdown tersedia; hasil dimasukkan ke dua lampiran audit tambahan esai.

Pada skenario kebutuhan wilayah terpencil 25% lebih rendah, median keunggulan KKT terhadap merata turun menjadi 1,837%; proporsional 1,909%. Dalam transisi perlindungan setara, tahun pertama KKT 6,956% dan proporsional 6,978%; tahun kelima masing-masing 7,484% dan 7,574%. Tidak ada dasar untuk mengklaim KKT selalu unggul. Koreksi V juga dilaporkan sebagai setengah jumlah perubahan absolut kuota dibagi total, tanpa melatih ulang laju. Skenario kebutuhan ini bukan estimasi galat BPS sebenarnya.

Badan esai akhir 9 halaman pada PDF yang dikonversi dari DOCX yang sama. Di luar badan tersedia cover, 15 pustaka, LM1–LM6, dua lampiran audit tambahan, dan 18 layar prototype. `paper/output/qa_report.json` memberi hitungan akhir, registri angka, dan status identitas. Dokumen memakai label DRAF karena nama tim/institusi/kota belum dikonfirmasi, belum ditandatangani, dan belum diperiksa Turnitin. Template orisinalitas lama memuat isian yang tampak sebagai contoh/versi sebelumnya, sehingga tidak dipakai untuk menebak identitas final.
