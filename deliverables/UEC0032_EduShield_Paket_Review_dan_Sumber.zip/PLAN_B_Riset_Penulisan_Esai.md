# Plan B: Riset & Penulisan Esai EduShield

Tujuan: esai ≤ 10 halaman dengan pola finalis SEC (analisis data → model → produk bernama, dengan tabel fitur dan SWOT), ditambah lampiran mockup gaya IFEST. Seluruh angka berasal dari pipeline v2 dan setiap klaim bersumber.

Rujukan: `00_BRIEFING_EduShield.md`, `HASIL_EduShield_v2.md`, `PLAN_A_Prototype_EduShield.md`.

## B0. Input yang sudah ada

- Draf lama: `UEC_LOGIKA UI 2026_IRIS Imba.docx`. Dipakai sebagai bahan, bukan kerangka.
- Putusan court + syarat pembebasan: `.court/20261030-165340/VERDICT.md`.
- Pipeline + hasil: `edushield/`, `HASIL_EduShield_v2.md`.
- Template resmi: `drive-download-20261015T121612Z-1-001/Template UEC.docx`. Lembar orisinalitas ada di folder yang sama.
- Contoh: `Contoh Finalist/` (Voxify, EggGuard) dan `Contoh Paper/Executive Summary IFEST Teen Tensors.pdf`.

## B1. Riset dan verifikasi sumber

Tiap klaim di esai harus punya sumber primer, atau ditandai jelas sebagai data media.

| # | Klaim | Status | Sumber primer yang dikejar | Tindakan |
|---|---|---|---|---|
| R1 | APS SMA/SMK 0,86%, SMP 0,54%, SD 0,09%; perdesaan 0,99% | Ada (BPS, Statistik Pendidikan 2025) | Publikasi BPS, catat nomor halaman/tabel | Verifikasi angka dan halaman |
| R2 | ATS 19,20% usia 16–18 | Sumber sekunder (GoodStats) | Tabel BPS asli | Ganti ke BPS |
| R3 | ATS nasional | Draf: 3,78 jt (CNBC) | Dasbor ATS Kemendikdasmen (catatan riset: 3.966.858 per 1 Apr 2026; DO 986.755) | Pilih satu angka dengan tanggal yang jelas |
| R4 | Perpres 3/2026 tentang anak tidak sekolah | Dari berita | JDIH/peraturan.go.id | Cek nomor, judul, pasal relevan |
| R5 | PIP SMA Rp1,8 juta/tahun | Dari berita (Bisnis.com) | Puslapdik / peraturan menteri | Ganti ke primer |
| R6 | BPK: Rp2,86 T untuk 5.364.986 siswa tidak tepat sasaran (IHPS II-2020) | Media + analisis DPR | IHPS II-2020 BPK | Kutip IHPS bila terjangkau |
| R7 | 2025: > 5,5 jt siswa layak gagal menerima PIP karena tidak ditandai sekolah | Media, belum terverifikasi | Rilis Kemendikdasmen/Puslapdik | **Pakai hanya bila primer ditemukan** |
| R8 | Efek PIP SMA: 2,8 lebih kecil peluang putus sekolah (dasar κ) | Abstrak terbaca | Listiyanto & Qibthiyyah, *JPBM* 8(2):113–127, 2022 (teks penuh) | Pastikan satuannya poin persen atau persen relatif. Bila relatif, kalibrasi ulang κ |
| R9 | BPS kemiskinan kab/kota 2025; penduduk kab/kota & umur 2026 | ✅ Diunduh | Sudah tercatat di `data/raw` | Masukkan ke pustaka (IEEE, format dataset) |
| R10 | Teori: Rumberger 2011; Sparrow 2007; Elmachtoub & Grigas 2022; Boyd & Vandenberghe 2004 | Ada | — | Pertahankan |
| R11 | **Baru:** proportional fairness = KKT untuk utilitas log | Belum | Kelly, Maulloo & Tan (1998), *J. Oper. Res. Soc.* | Tambahkan |
| R12 | **Baru:** water-filling klasik | Belum | Cover & Thomas, *Elements of Information Theory* (bab kapasitas kanal paralel) | Tambahkan (opsional) |
| R13 | GLM binomial / regresi logistik fraksional | Belum | Papke & Wooldridge (1996), *J. Appl. Econometrics*; atau McCullagh & Nelder | Tambahkan satu |
| R14 | UU 27/2022 PDP: dasar pemrosesan, data anak | Hanya sitasi | Teks UU: pasal dasar pemrosesan, pasal data anak | Rumuskan kalimat tata kelola yang tepat |
| R15 | Kovariat tambahan opsional: rata-rata lama sekolah kab, jarak/akses SMA (Podes) | Belum | Tabel BPS | **Opsional.** Lewati bila waktu sempit |

Pengelolaan pustaka: satu berkas `pustaka.bib` atau tabel IEEE. Target 15–20 rujukan, ≥ 60% jurnal, peraturan, atau data resmi.

## B2. Finalisasi analisis dan aset

**Kode** (di `edushield/`):
- `edushield.py --export` → `app_data.json` (dipakai juga oleh Plan A7.2).
- `figs.py` → semua gambar (PNG 300 dpi, palet sama dengan identitas visual Plan A).
- `angka.json`: registri setiap angka yang muncul di esai, beserta kuncinya (misalnya `gain_kkt_median`). Satu sumber kebenaran untuk QA B6.
- Seed tetap. `python edushield.py 30 && python figs.py` mereproduksi semuanya.

**Gambar badan esai** (maks 7):

| No | Isi | Data |
|---|---|---|
| G1 | Urgensi: APS per jenjang + ATS per umur | BPS nyata |
| G2 | Peta % miskin kab/kota (nyata) + sebaran laju simulasi | Nyata + simulasi (berlabel) |
| G3 | Kinerja prediksi: prediksi vs benar + kalibrasi (3 model) | Simulasi |
| G4 | **Ilustrasi water-filling**: 5 wilayah contoh sebagai bejana, garis λ\* | Simulasi |
| G5 | Perbandingan skema (median + interval 90%) dan garis oracle | Monte Carlo |
| G6 | Ketahanan: (a) heatmap regret, (b) lintasan hold-harmless | Monte Carlo |
| G7 | EduShield: matriks M→T→S + arsitektur 4 lapis + 1 komposit layar | Plan A |

**Tabel badan esai** (maks 3):
- T1 Kinerja prediksi
- T2 Skema alokasi (siswa tertahan, keunggulan, cakupan)
- T3 Fitur EduShield per peran (gaya EggGuard Tabel 6, dipetakan ke S1–S4)

**Lampiran matematis** (tidak dihitung halaman; disusun sebelum lampiran prototipe):
- **LM1** Perumusan: s_i(x) = V_i ρ_i (1 − e^{−κx/V_i}); program konveks; KKT; solusi bentuk tertutup L3; λ\* dengan bagi-dua. ρ = laju terprediksi, **tanpa p̂**.
- **LM2** DGP lengkap: persamaan η, parameter, alasan bentuknya berbeda dari model; definisi V_i dari data BPS.
- **LM3** Kalibrasi κ: efek rata-rata per penerima = 2,8 pp → κ = 1,74; sensitivitas.
- **LM4** Proporsional sebagai KKT untuk Σ w_i ln x_i (dua baris turunan), sebagai penjelasan temuan "KKT ≈ proporsional".
- **LM5** Verifikasi langkah demi langkah untuk 5 wilayah (Sumba Tengah, Nduga, Kota Yogyakarta, Kota Surabaya, Supiori), menggantikan Lampiran 2 lama.
- **LM6** Pseudokode + daftar berkas reproduksi.

## B3. Kerangka esai (≤ 10 halaman) dan peta bobot nilai

| Bagian | Hal. | Isi | Bobot yang dilayani |
|---|---|---|---|
| Cover | — | Judul baru (usulan: *"EduShield: Sistem Pendukung Keputusan Kuota PIP Berbasis Prediksi Laju Putus Sekolah dan Optimasi Imbal Hasil Menurun"*), subtema, identitas | Format |
| **1 Pendahuluan** | 1,25 | 1.1 Latar: kait Sumba Tengah dengan **angka nyata** (miskin 29,23%); data urgensi (R1–R4); salah sasaran PIP (R6); celah: kuota belum memperhitungkan imbal hasil menurun (asumsi kerja). 1.2 Rumusan: (1) seberapa baik laju putus sekolah diprediksi di provinsi tak terlihat; (2) bagaimana kuota dibagi optimal dan seberapa tahan; (3) bagaimana sistemnya dijalankan. 1.3 Tujuan: dipetakan ke *cerdas/adaptif/berkelanjutan* | Urgensi 15, Tema 5 |
| **2 Landasan Teori** | 1,25 | 2.1 Dari prediksi ke keputusan (Elmachtoub); GLM laju; validasi out-of-province. 2.2 Imbal hasil menurun, program konveks, KKT, water-filling, harga bayangan. 2.3 Proportional fairness sebagai kasus khusus. 2.4 Bukti efek PIP dan dasar κ | Matematika 20 |
| **3 Pembahasan** | 6,25 | Lihat sub-bagian di bawah | Inovasi 20, Matematika 20, Data 10, Aktualisasi 15 |
| 3.1 Data & desain studi | 0,75 | Kovariat BPS nyata + outcome simulasi terbuka; alasan semi-sintetis; G2 | Data 10 |
| 3.2 Melihat lebih awal | 1,0 | T1, G3; AUC 0,91 jujur; regresi sederhana ≈ LightGBM | Matematika |
| 3.3 Membagi dengan cerdas | 1,25 | G4 (bejana), T2, G5; **greedy menjangkau Zona Merah lebih luas tetapi menahan lebih sedikit siswa**; KKT ≈ proporsional ≈ 97,8% oracle; λ\* = 6,8 siswa/Rp1 miliar | Inovasi, Matematika |
| 3.4 Seberapa tahan | 0,75 | G6; 17/18 sel regret; tingkat pagu (paling bernilai saat pagu ketat); biaya terpencil; hold-harmless ≈ −0,3 pp | Matematika |
| 3.5 EduShield: produknya | 1,5 | Matriks M→T→S; arsitektur 4 lapis; alur 3 peran; T3 fitur; G7; rujukan ke Lampiran A–C (gaya IFEST); batas produk | Aktualisasi 15, Inovasi |
| 3.6 Aktualisasi | 1,0 | Peta jalan 3 tahap (Plan A11), indikator keberhasilan, tata kelola & PDP (R14), SWOT ringkas (gaya EggGuard) | Aktualisasi 15 |
| **4 Penutup** | 0,75 | Kesimpulan: 3 butir terukur, dengan label "dalam simulasi". Keterbatasan: outcome simulasi, κ dari satu studi, model meremehkan wilayah paling ekstrem. Rekomendasi: pilot 2 provinsi | Format, Urgensi |
| Daftar Pustaka | — | IEEE, 15–20 rujukan | Data 10 |
| Lampiran | — | LM1–LM6, lalu Lampiran prototipe 1–6 (Plan A9) | Aktualisasi, Matematika |

## B4. Pedoman penulisan

- **Suara:** "kami"; kalimat aktif; satu gagasan per paragraf; buka bagian dengan temuan, bukan teori.
- **Kata terlarang:** "andal", "meyakinkan", "terbukti", "sempurna". Ganti dengan "dalam simulasi", "menunjukkan", "mendekati".
- **Label simulasi:** setiap angka manfaat diberi frasa "dalam simulasi" minimal sekali per paragraf. Angka nyata BPS tanpa label.
- **Glosarium tetap:** *laju putus sekolah* (bukan APS), *siswa rentan*, *kuota*, *siswa tertahan* (bukan "diselamatkan"), *harga bayangan*, *Zona Merah* (hanya di dasbor). *Water-filling*, *hold-harmless*, dan *out-of-province* dicetak miring sesuai PUEBI.
- **Sitasi:** IEEE [n] berurutan menurut kemunculan. Setiap angka eksternal punya [n].
- **Keterangan gambar:** kalimat utuh yang bisa dibaca tanpa teks badan.
- **Urutan menulis:** 3.2 → 3.3 → 3.4 (angka) → 3.5 → 3.6 → 2 → 1 → 4. Pendahuluan ditulis terakhir agar janjinya sesuai isi.
- **Pengecekan gaya** di akhir dengan skill `humanizer`/`ai-paraphrase`, tanpa mengubah angka.

## B5. Produksi dokumen

- Basis: `Template UEC.docx`. Isi lewat skrip (python-docx) agar dapat diregenerasi, atau lewat skill `great-paper` (struktur `/paper/script` → `/paper/output` PDF+DOCX).
- **Format:**
  - A4; margin 4/3/3/3 cm; TNR 12; spasi 1,5 (pustaka 1); rata kanan-kiri;
  - judul bab 14 tebal, subbab 12 tebal;
  - persamaan dengan Word Equation (OMML) dan nomor di kanan.
- **Hitung halaman** dari PDF hasil konversi: halaman Pendahuluan s.d. akhir Penutup ≤ 10.
- **Lampiran prototipe:** gambar dari Plan A7.11 dengan keterangan templat A9.
- **Berkas:** `NomorPeserta_NamaTim_Esai.pdf`.

## B6. Gerbang mutu (semua harus lulus sebelum kirim)

1. **Konsistensi angka:** skrip memindai teks DOCX dan mencocokkan setiap angka berkunci dengan `angka.json`. Nol selisih.
2. **Sitasi:** semua [n] ada di pustaka dan sebaliknya; URL hidup; tanggal akses tercatat. Bisa memakai `/ars-citation-check` atau `citation-management`.
3. **Syarat court dipenuhi:**
   - ρ tanpa p̂;
   - kurva optimasi ≠ kurva evaluasi;
   - hold-harmless dihitung;
   - DGP dibuka;
   - label simulasi;
   - tanpa ranking siswa;
   - PDP dirumuskan.
4. **Sidang court ulang** atas draf v2. Target: NOT GUILTY. Bila GUILTY, perbaiki "Conditions for acquittal" lalu ulangi sekali.
5. **Skor mandiri per rubrik** (tabel 7 kriteria, skor 1–5 + bukti halaman).
6. **Format:** cek list B5.
7. **Orisinalitas:** parafrase seluruh kutipan; target Turnitin < 20% (kalau ada akses cek).

## B7. Paket submisi

- [ ] `NomorPeserta_NamaTim_Esai.pdf` (cover terisi: nomor peserta, nama tim, anggota, PT)
- [ ] `NomorPeserta_NamaTim_LembarOrisinalitas.pdf` (ditandatangani)
- [ ] Unggah lewat `ristek.link/SubmisiBerkasUECLOGIKAUI-2026`
- [ ] Arsipkan DOCX sumber, `edushield/` (kode + data), dan tautan prototipe untuk babak final

## B8. Urutan kerja dan ketergantungan

| Fase | Plan B | Plan A paralel | Est. jam |
|---|---|---|---|
| 1 | B1 verifikasi R1–R8, R11–R14 | A7.1 spesifikasi, A7.3 geo, A7.4 identitas | 4 |
| 2 | B2 `--export`, `figs.py`, `angka.json`, LM1–LM6 | A7.2 pakai `--export`; A7.6 solver JS | 6 |
| 3 | B3 kerangka beku; B4 tulis 3.2–3.4 | A7.5 wireframe; A7.7 bangun layar | 8 |
| 4 | B4 tulis 3.5–3.6 (butuh A7.1 + komposit) → 2 → 1 → 4 | A7.8–A7.10 | 6 |
| 5 | B5 tata letak + lampiran | A7.11 tangkapan layar + keterangan | 4 |
| 6 | B6 gerbang mutu + court ulang | A7.12 publikasi (opsional) | 3 |
| 7 | B7 kirim | — | 1 |

Total Plan B sekitar 32 jam, Plan A sekitar 35 jam. Keduanya bisa berjalan paralel bila ada 2 orang.

**Jalur Kilat** (bila tenggat sangat dekat): B1 hanya R1, R6, R8 → B2 tanpa G6 → tulis ulang esai dengan angka v2 → Plan A dipangkas menjadi 6 mockup statis (A1, A3, A4, A5, A7, B1) di lampiran → B6 hanya butir 1, 3, dan 6.