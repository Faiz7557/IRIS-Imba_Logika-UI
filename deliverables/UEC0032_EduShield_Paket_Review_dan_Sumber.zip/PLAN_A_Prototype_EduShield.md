# Plan A: Prototipe Solusi EduShield

Tujuan plan ini adalah menghasilkan **produk nyata yang benar-benar menghitung**: dasbor web keputusan kuota PIP yang memakai hasil pipeline v2 dan solver KKT. Plan ini juga menghasilkan **set mockup berkode berketerangan** untuk lampiran esai, mengikuti gaya Executive Summary IFEST.

Rujukan: `00_BRIEFING_EduShield.md` (keputusan K1–K6), `HASIL_EduShield_v2.md` (angka), `edushield/edushield.py` (mesin).

## A0. Batas produk

- **Apa:** sistem pendukung keputusan (DSS) untuk menetapkan kuota PIP SMA/SMK per kab/kota. Isinya peringatan dini risiko, simulasi alokasi, transisi bertahap, dan siklus kalibrasi.
- **Bukan:** alat penilai siswa individual, pengganti keputusan pejabat, atau alat yang mengklaim dampak riil sebelum uji coba.
- **Anti-goal** (gagal walau berjalan): ada angka simulasi tanpa label; ada daftar siswa berperingkat; usulan sistem tampil sebagai keputusan final; daerah tidak bisa melihat alasan kuotanya.

## A1. Pengguna dan skenario (default K1–K2)

| Peran | Kapan membuka | Keputusan di layar |
|---|---|---|
| **Analis kuota pusat** (Puslapdik/Kemendikdasmen), pengguna utama | Menjelang penetapan kuota tahunan dan saat pagu berubah | Usulan kuota per kab/kota, besar pagu tambahan yang layak diminta (harga bayangan), laju transisi |
| **Dinas Pendidikan** provinsi/kab | Setelah kuota diumumkan; tiap semester | Memahami alasan kuota, mengajukan koreksi data, melaporkan realisasi |
| **Admin data/model** | Tiap semester | Memuat data baru, memantau kinerja prediksi, menangani anomali |

## A2. Matriks telusur Masalah → Tujuan → Komponen

| Masalah (M) | Tujuan (T) + indikator | Komponen (S) |
|---|---|---|
| **M1** Wilayah berisiko terlambat dikenali; kuota disusun dari pemadanan administratif dan pola tahun lalu | **T1** Kenali laju putus sekolah tiap kab/kota sebelum tahun anggaran, termasuk wilayah tanpa riwayat. *Indikator:* Spearman dan MAE prediksi vs realisasi semester | **S1 Radar Risiko**: peta laju terprediksi + interval + kontribusi faktor |
| **M2** Kuota dibagi tanpa memperhitungkan imbal hasil menurun (merata atau prioritas buta) | **T2** Maksimalkan siswa tertahan per rupiah pada pagu tetap. *Indikator:* siswa tertahan/Rp1 miliar; % terhadap batas atas (oracle) | **S2 Simulator Kuota**: water-filling KKT, pembanding skema, harga bayangan λ\* |
| **M3** Perubahan kuota yang drastis ditolak daerah; pagu berubah-ubah | **T3** Transisi bertahap yang dapat diterima. *Indikator:* penurunan kuota per wilayah ≤ 10%/tahun; tahun mencapai ≥ 95% manfaat optimum | **S3 Peta Jalan Transisi**: lintasan hold-harmless + skenario pagu |
| **M4** Data usulan tidak andal (BPK: Rp2,86 T salah sasaran) dan tidak ada umpan balik | **T4** Siklus umpan balik semesteran dan audit anomali. *Indikator:* waktu siklus kalibrasi; jumlah anomali tertangani | **S4 Siklus Kalibrasi**: unggah realisasi, re-estimasi ρ dan κ, tanda anomali, banding dinas |

## A3. Kriteria desain (diturunkan dari M1–M4 dan putusan court)

1. **Setiap angka punya "mengapa"**: skor risiko selalu disertai kontribusi faktor; kuota selalu disertai posisinya pada kurva manfaat (M1, M3).
2. **Jujur soal ketidakpastian**: interval prediksi ditampilkan; pita "DATA SIMULASI" tampil di setiap layar prototipe.
3. **Manusia yang memutuskan**: sistem memberi *usulan*. Setiap override dicatat beserta alasannya.
4. **Hanya agregat kab/kota**: tidak ada data siswa; selaras UU 27/2022 tentang PDP.
5. **Satu layar, satu keputusan.**
6. **Dapat diaudit**: versi model, versi data, dan parameter tercetak di setiap ekspor.
7. **Ringan**: berjalan di peramban perangkat kantor biasa. Solver berjalan di klien, sehingga simulasi responsif tanpa server.

## A4. Arsitektur

**Visi produksi (4 lapis):**
1. **Lapis data**: BPS (kemiskinan, penduduk), agregat Dapodik/DTSEN per kab/kota, realisasi pencairan dan retensi PIP.
2. **Mesin analitik** (Python, dijalankan per semester): validasi data → GLM laju out-of-province → kalibrasi κ → KKT → uji ketahanan.
3. **Paket data berversi**: `app_data.json` + hash, satu paket per semester.
4. **Antarmuka web statis**: solver KKT di JavaScript untuk *what-if* waktu nyata; ekspor Lembar Keputusan (PDF).

**Prototipe** memakai susunan yang sama dalam skala kecil: lapis 1–3 = `edushield.py --export`; lapis 4 = satu halaman HTML/JS.

**Stack prototipe** (default, bisa diganti):
- HTML + JS modul, tanpa build;
- Leaflet 1.9.4 (peta) dan Chart.js 4 (grafik) dari cdnjs;
- CSS cetak untuk PDF;
- data dari `app_data.json`.

Alasannya: tanpa server, mudah dipublikasikan, dan tangkapan layarnya rapi.

## A5. Kontrak data `app_data.json`

```text
meta:     versi_model, versi_data, tanggal, sumber[], label="SIMULASI",
          params{C0, share, alpha, beta, kappa}
kab[514]: id, nama, prov, gugus, kota, p0, pop1519, V,
          r_hat, r_lo, r_hi,                      # interval dari sebaran ulangan lipatan
          kontribusi{kemiskinan, pemuda, kota, gugus},  # suku linier logit GLM, aditif
          x{merata, kemiskinan, greedy, proporsional, edushield, oracle},
          hh[5]                                    # lintasan hold-harmless
nasional: skema_mc{median,p5,p95}, regret{kopt|kurva}, lambda_per_kappa,
          kurva_pagu{share: gain}, kinerja_prediksi{...}
geo:      TopoJSON kab/kota tersederhanakan, kunci = id
```

Kontribusi faktor memakai suku linier GLM (setara SHAP untuk model linier, eksak dan murah). Dengan begitu LightGBM/SHAP tidak perlu ada di produk.

## A6. Inventaris layar

Kolom "Proto" menunjukkan apakah layar dibangun interaktif (✔) atau cukup mockup statis untuk lampiran (◻).

**Identitas (Lampiran 1):** logo, varian satu warna, tagline (usulan: *"Setiap rupiah, sampai ke yang paling butuh"*), palet, tipografi.

**A: Analis pusat**

| Kode | Layar | Isi kunci | Menjawab | Proto |
|---|---|---|---|---|
| A1 | Beranda nasional | Pagu, siswa rentan, proyeksi siswa tertahan vs merata, λ\*, status versi data | T2 | ✔ |
| A2 | Radar Risiko | Choropleth laju terprediksi, filter gugus, daftar 20 teratas + interval | M1/T1 | ✔ |
| A3 | Profil kab/kota | Laju ± interval, batang kontribusi faktor, kuota merata vs usulan, **kurva manfaat wilayah dengan garis "permukaan air"** | M1, M2 | ✔ |
| A4 | Simulator Kuota | Penggeser pagu, α, β, κ, biaya terpencil; **visual bejana water-filling**; tabel hasil | M2/T2 | ✔ |
| A5 | Bandingkan Skema | Batang siswa tertahan (merata, kemiskinan, greedy, proporsional, KKT, oracle) + kartu "mengapa greedy kalah" | M2 | ✔ |
| A6 | Uji Ketahanan | Heatmap regret κ_opt × kurva benar | T2 | ◻ |
| A7 | Peta Jalan Transisi | Lintasan 5 tahun per gugus; batas 10%; manfaat per tahun | M3/T3 | ✔ |
| A8 | Lembar Keputusan | Pratinjau cetak: kuota per kab, alasan, versi, kolom pengesahan | A3.6 | ✔ (cetak) |

**B: Dinas Pendidikan**

| Kode | Layar | Isi kunci | Menjawab | Proto |
|---|---|---|---|---|
| B1 | Beranda daerah | Kuota tahun ini vs lalu, alasan dalam bahasa awam | A3.1 | ✔ |
| B2 | "Mengapa skor kami" | Kontribusi faktor + perbandingan dengan kab serupa | M1 | ✔ |
| B3 | Ajukan koreksi data | Formulir banding + bukti + status | M4 | ◻ |
| B4 | Lapor realisasi | Unggah rekap agregat pencairan dan retensi | M4/T4 | ◻ |

**C: Admin data/model**

| Kode | Layar | Isi kunci | Menjawab | Proto |
|---|---|---|---|---|
| C1 | Muat data semester | Validasi skema, pencocokan 514 nama wilayah | M4 | ◻ |
| C2 | Kalibrasi | Prediksi vs realisasi semester lalu; pembaruan κ | T4 | ◻ |
| C3 | Audit & anomali | Lonjakan tak wajar, log override | M4 | ◻ |

**MVP interaktif:** A1–A5, A7, A8, B1, B2. Sisanya mockup statis dengan gaya visual yang sama.

## A7. Rincian kerja

Estimasi jam berlaku untuk 1 orang.

| # | Pekerjaan | Hasil | Selesai bila | Est. |
|---|---|---|---|---|
| A7.1 | Jawab K1–K4; kunci matriks A2, kriteria A3, inventaris A6 | Spesifikasi beku | User setuju | 1 |
| A7.2 | `edushield.py --export`: interval r̂ (persentil antar-ulangan), kontribusi GLM, semua skema, hh, nasional | `app/app_data.json` | Skema JSON sesuai A5; 514 baris | 3 |
| A7.3 | Batas wilayah: cari TopoJSON kab/kota (cek lisensi, cakupan 38 provinsi termasuk 4 provinsi Papua baru, pencocokan nama dengan `_norm`). **Cadangan:** peta tingkat provinsi + peta petak (tile grid) kab | `app/geo.json` | ≥ 99% wilayah tercocok | 3 |
| A7.4 | Identitas visual: logo SVG, palet (aman buta warna), tipografi, tagline | Lampiran 1 | Terbaca hitam-putih | 2 |
| A7.5 | Wireframe semua layar (A–C) | Sketsa | Alur A1→A8 runtut | 2 |
| A7.6 | Port solver KKT + skema pembanding ke JS (`kkt.js`) | Modul | Lulus uji A8.1 | 2 |
| A7.7 | Bangun layar ✔ (A1–A5, A7, B1, B2) | `app/index.html` | Interaktif, < 100 ms per simulasi | 10 |
| A7.8 | A8 Lembar Keputusan (CSS cetak) | PDF | Versi dan parameter tercetak | 2 |
| A7.9 | Mockup statis ◻ (A6, B3, B4, C1–C3) dengan komponen yang sama | PNG | Konsisten dengan A7.7 | 4 |
| A7.10 | Uji (A8) + perbaikan | Laporan uji | Semua lulus | 2 |
| A7.11 | Tangkapan layar resolusi tinggi + keterangan lampiran (A9) | `lampiran/*.png` + teks | Tiap gambar menyebut M/T/kriteria | 3 |
| A7.12 | Publikasi (opsional): Artifact/GitHub Pages + QR | Tautan | Dapat dibuka publik | 1 |

Total sekitar 35 jam. Jalur paralel: A7.3, A7.4, dan A7.6 tidak saling bergantung.

## A8. Pengujian

1. **Kesetaraan solver:** `kkt.js` vs `edushield.kkt` pada 3 konfigurasi (pagu 30/55/80%). Alokasi per wilayah harus sama dalam toleransi relatif 1e-6, Σc·x = B, dan semua batas terpenuhi. Uji dijalankan di peramban dengan `console.assert` dan diringkas dalam satu tabel.
2. **Angka konsisten:** keunggulan per skema di A5 sama dengan `summary.json` (seed 0).
3. **Label:** pita "DATA SIMULASI" ada di setiap layar dan di ekspor.
4. **Aksesibilitas:** kontras ≥ 4,5:1; warna bukan satu-satunya pembawa makna (pola/ikon pada peta); navigasi papan ketik.
5. **Kinerja:** solve 514 wilayah < 100 ms; muat awal < 3 detik.
6. **Wajar:** wilayah risiko rendah berada di lantai α; tidak ada wilayah yang turun lebih dari 10% di lintasan hh.

## A9. Produksi lampiran (gaya IFEST)

**Struktur lampiran:**
- Lampiran 1: Identitas visual
- Lampiran 2: Alur analis pusat (A1–A8)
- Lampiran 3: Sisi dinas (B1–B4)
- Lampiran 4: Siklus kalibrasi (C1–C3)
- Lampiran 5: Arsitektur 4 lapis + kontrak data
- Lampiran 6: Rencana uji coba

Lampiran matematis (DGP, kalibrasi κ, KKT) diatur di Plan B.

**Templat keterangan:** *"Gambar X. [Nama layar] ([kode]). [Apa yang dilihat dan diputuskan pengguna]. [Alasan desain]. Menjawab [M/T/kriteria]. Seluruh angka bersifat simulasi."*

Contoh: *"Gambar L. Profil Kab. Sumba Tengah (A3). Garis biru menandai 'permukaan air' λ\*: kuota berhenti ditambah tepat saat manfaat marjinal per rupiah wilayah ini sama dengan wilayah lain. Menjawab M2 dan kriteria 1."*

Pakai 14–18 gambar dalam format ponsel/desktop yang konsisten. Pada tiap layar, sorot satu elemen kunci dengan anotasi bernomor.

## A10. Risiko dan cadangan

| Risiko | Cadangan |
|---|---|
| TopoJSON kab/kota tidak lengkap atau berlisensi ketat | Peta provinsi + peta petak kab/kota |
| Waktu habis sebelum A7.7 selesai | Turunkan semua layar ◻ ke mockup statis berbasis komponen HTML yang sama |
| Model **meremehkan wilayah paling berisiko** (Supiori: r̂ 0,23 vs benar 0,38) | Tampilkan interval; catat di C2 sebagai bias yang dipantau; batas β dan jaring α tetap melindungi |
| Juri mengira angka riil | Pita simulasi + kalimat di setiap keterangan lampiran |
| Larangan tautan eksternal di lomba | QR hanya di lampiran, bukan syarat untuk memahami esai |

## A11. Peta jalan implementasi (bahan §Aktualisasi di esai)

| Tahap | Waktu | Isi | Indikator lulus |
|---|---|---|---|
| 0 Pilot data | 0–6 bln | 2 provinsi prioritas (misalnya NTT dan Papua Pegunungan): padankan agregat Dapodik–DTSEN–BPS; kalibrasi model dengan data riil | MAE prediksi ≤ 0,7 pp; 100% kab tercocok |
| 1 Uji alokasi | 6–18 bln | Sebagian kuota tambahan dialokasikan EduShield vs kontrol (desain bertahap/kuasi-eksperimen) | Retensi naik vs kontrol; estimasi κ per wilayah |
| 2 Pelembagaan | 18–36 bln | Siklus semesteran nasional, hold-harmless 10%/tahun, banding dinas | ≥ 95% manfaat optimum di tahun ke-3; tidak ada wilayah turun > 10%/tahun |

**Tata kelola:** akses berbasis peran; hanya agregat; log override; audit bias tahunan (khususnya Maluku–Papua); dasar hukum PDP berupa pelaksanaan tugas kepentingan umum dengan data agregat (rumusan final diverifikasi di Plan B).