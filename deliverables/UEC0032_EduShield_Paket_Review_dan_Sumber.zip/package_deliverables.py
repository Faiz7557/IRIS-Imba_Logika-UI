"""Package only task deliverables and reproducible sources; exclude render scratch files."""
from pathlib import Path
import json,zipfile,hashlib
ROOT=Path(__file__).parent
OUT=ROOT/'deliverables';OUT.mkdir(exist_ok=True)
q=json.loads((ROOT/'paper/output/qa_report.json').read_text(encoding='utf8'))
b=json.loads((ROOT/'edushield/verification/browser_report.json').read_text(encoding='utf8'))
assert q['body_pages']<=10 and b['status']=='PASS'
def archive(name,files):
 files=sorted(set(files))
 with zipfile.ZipFile(OUT/name,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in files:z.write(p,p.relative_to(ROOT))
 data=(OUT/name).read_bytes()
 return {'file':name,'bytes':len(data),'files':len(files),'sha256':hashlib.sha256(data).hexdigest()}

app=[p for p in (ROOT/'edushield/app').rglob('*') if p.is_file()]
app+=[ROOT/'edushield/README.md',ROOT/'edushield/DESIGN.md']
app+=list((ROOT/'edushield/verification').glob('*.json'))
records=[archive('UEC0032_EduShield_Prototype_Offline.zip',app)]
files=[]
for folder in ['edushield','paper/script','.court/20261030-195636']:
 files.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for name in ['PLAN_A_Prototype_EduShield.md','PLAN_B_Riset_Penulisan_Esai.md','00_BRIEFING_EduShield.md','ANALISIS_DAN_EKSEKUSI_EduShield.md','package_deliverables.py']:
 files.append(ROOT/name)
files+=list((ROOT/'paper/output').glob('*.pdf'))+list((ROOT/'paper/output').glob('*.docx'))+[ROOT/'paper/output/qa_report.json',ROOT/'paper/output/CHECKLIST_REVIEW.md',ROOT/'paper/output/esai_terbaca.md',ROOT/'paper/README.md']
files+=[ROOT/'drive-download-20261015T121612Z-1-001/Template UEC.docx',ROOT/'drive-download-20261015T121612Z-1-001/Lembar Pernyataan Orisinalitas Karya (UEC).docx']
records.append(archive('UEC0032_EduShield_Paket_Review_dan_Sumber.zip',files))
(OUT/'manifest.json').write_text(json.dumps({'label':'DRAFT REVIEW — NOT SUBMITTED','body_pages':q['body_pages'],'court':'NOT GUILTY 12–0, demonstration only','artifacts':records},indent=2,ensure_ascii=False),encoding='utf8')
print(json.dumps(records,indent=2))
