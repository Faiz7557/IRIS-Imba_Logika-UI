# Briefing EduShield: rangkuman sesi dan to-do induk

Disusun 30 Okt 2026. Dokumen ini adalah pintu masuk. Detail eksekusi ada di dua plan:

- [PLAN_A_Prototype_EduShield.md](PLAN_A_Prototype_EduShield.md): produk/prototipe solusi.
- [PLAN_B_Riset_Penulisan_Esai.md](PLAN_B_Riset_Penulisan_Esai.md): riset dan penulisan esai.

`RENCANA_PENGEMBANGAN_EduShield.md` sudah digantikan oleh dokumen ini. Bagian P0 di sana sudah dikerjakan; hasilnya ada di `HASIL_EduShield_v2.md`.

## 1. Konteks lomba

- UEC LOGIKA UI 2026, babak penyisihan. Tema: *Peran Ilmu Matematika dalam Mewujudkan Sistem yang Cerdas, Adaptif, dan Berkelanjutan*. Subtema: **Pendidikan dan Sosial Masyarakat**.
- Format: Cover → Pendahuluan (latar, rumusan, tujuan) → Landasan Teori → Pembahasan → Penutup → Daftar Pustaka (IEEE) → Lampiran (opsional). A4; margin kiri 4, kanan/atas/bawah 3 cm; TNR 12; spasi 1,5 (pustaka 1); rata kanan-kiri; **maksimal 10 halaman di luar cover, pustaka, dan lampiran**; PUEBI; Turnitin ≤ 20%.
- Bobot nilai:

| Kriteria | Bobot |
|---|---|
| Format (sistematika, kesesuaian judul) | 15% |
| Keunikan/kreativitas/inovasi | 20% |
| Urgensi & kebermanfaatan | 15% |
| Kesesuaian tema | 5% |
| Kejelasan aktualisasi | 15% |
| Kevalidan data & literatur | 10% |
| Kesesuaian matematika dengan gagasan | 20% |

- Berkas: `NomorPeserta_NamaTim_Esai.pdf` + `NomorPeserta_NamaTim_LembarOrisinalitas.pdf` lewat Google Form.
- ⚠ **Jadwal TM menyebut submisi penyisihan ditutup 30 Okt 2026.** Pastikan tenggat yang berlaku sebelum memakai plan penuh.

## 2. Yang sudah terjadi di sesi ini

1. **Sidang court atas draf lama** (`.court/20261030-165340/`): GUILTY 9–3, dengan putusan "pertahankan ide, jangan kirim draf ini". Tuduhan yang terbukti:
   - ρ = r̂·p̂ rusak (Kota Yogyakarta jatuh ke lantai);
   - angka simulasi disajikan seperti temuan;
   - +12,9% sirkular karena κ tanpa sumber;
   - (minor) hold-harmless bertentangan dengan hasil optimasi, janji daftar siswa berperingkat, dan UU PDP hanya disitasi.
2. **Rencana P0** ditulis, lalu dikerjakan.
3. **Data nyata BPS** dikumpulkan untuk 514 kab/kota: % penduduk miskin 2025 dan penduduk total serta usia 15–19 tahun 2026. Tersimpan di `edushield/data/raw/`.
4. **Pipeline v2** (`edushield/edushield.py`, cek `test_kkt.py`) berisi:
   - GLM laju langsung out-of-province;
   - DGP terbuka yang berbeda bentuk dari model;
   - κ = 1,74, dikalibrasi ke efek PIP SMA 2,8 pp (Listiyanto & Qibthiyyah, 2022);
   - 5 skema pembanding + oracle, regret matrix, hold-harmless 5 tahun, uji tingkat pagu, uji biaya terpencil;
   - 30 ulangan Monte Carlo.
5. **Hasil v2** (`HASIL_EduShield_v2.md`):
   - EduShield +7,3% [5,7; 9,4] atas merata, mencapai 97,8% dari oracle;
   - greedy dan peringkat kemiskinan hanya +2,3–2,4%;
   - **proporsional risiko ≈ KKT** (+7,5%), karena alokasi proporsional = solusi KKT untuk utilitas logaritmik;
   - harga bayangan 6,8 siswa per Rp1 miliar;
   - AUC Zona Merah 0,91;
   - hold-harmless hanya mengurangi keunggulan sekitar 0,3 pp;
   - unggul di 17 dari 18 sel regret.
6. **Contoh dibaca:**
   - Voxify dan EggGuard (finalis SEC): analisis data → model → aplikasi bernama dengan mockup, tabel fitur, dan SWOT di badan esai.
   - IFEST Nyambung: matriks M→T→S, arsitektur berlapis, rencana realisasi, etika/validasi; mockup berkode (A1–A6, B, C, D) dengan alasan desain di **lampiran**.

## 3. Tesis baru (sudah diputuskan, berlaku di kedua plan)

> Kuota bantuan pendidikan sebaiknya dibagi dengan prinsip **imbal hasil menurun, bukan sekadar prioritas risiko**. Matematika (KKT water-filling) memberi aturan bagi itu, batas atas manfaatnya, harga satu rupiah tambahan, dan cara transisi yang dapat diterima daerah. Keputusannya tahan terhadap pilihan model.

Larangan: klaim "andal", "meyakinkan", "terbukti"; angka simulasi tanpa label; daftar siswa berperingkat.

## 4. Keputusan terbuka (perlu jawaban user)

| # | Keputusan | Default yang dipakai plan | Dampak bila diubah |
|---|---|---|---|
| K1 | Pengguna utama produk | **Analis kuota pusat (Puslapdik/Kemendikdasmen)**; pengguna kedua **Dinas Pendidikan** provinsi/kab | Urutan layar dan kedalaman simulator |
| K2 | Bentuk produk | **Dasbor web** (desktop) + tampilan ringkas responsif untuk dinas | Mockup ponsel vs desktop |
| K3 | Tingkat "nyata" prototipe | **Prototipe web interaktif yang benar-benar menghitung** (solver KKT di peramban, data pipeline v2); tangkapan layarnya jadi lampiran | Figma-only lebih cepat tapi tidak "produk nyata" |
| K4 | Nama & identitas | Tetap **EduShield** | Logo, tagline, judul esai |
| K5 | Identitas tim | Belum ada (cover masih placeholder) | Cover & nama berkas |
| K6 | Tenggat | Belum pasti (lihat ⚠ di atas) | Plan penuh atau Jalur Kilat |

## 5. To-do induk (urut, lintas plan)

Status: ✅ selesai · ⏳ berikutnya · ☐ belum.

**Fondasi**
- ✅ Kurasi court draf lama
- ✅ Pipeline v2 + data BPS + uji P0
- ☐ Jawab K1–K6

**Plan A: Prototipe** (detail di Plan A)
- ⏳ A1 Spesifikasi produk: matriks M→T→S, kriteria desain, inventaris layar, kontrak data
- ☐ A2 Ekspor data aplikasi dari pipeline (+ kontribusi faktor dan ketidakpastian)
- ☐ A3 Identitas visual
- ☐ A4 Wireframe → mockup hi-fi
- ☐ A5 Bangun prototipe web interaktif
- ☐ A6 Uji kesetaraan solver JS–Python, aksesibilitas, label simulasi
- ☐ A7 Tangkapan layar + keterangan lampiran
- ☐ A8 Publikasi tautan (opsional)

**Plan B: Riset & penulisan** (detail di Plan B)
- ⏳ B1 Verifikasi sumber primer + literatur tambahan
- ☐ B2 Finalisasi analisis: gambar, tabel, lampiran matematis
- ☐ B3 Kerangka 10 halaman, dipetakan ke bobot nilai
- ☐ B4 Penulisan draf v2
- ☐ B5 Tata letak sesuai template + lampiran prototipe
- ☐ B6 QA: konsistensi angka, sitasi, Turnitin, sidang court ulang
- ☐ B7 Paket submisi

**Ketergantungan kunci:** B4 §3.4 butuh A1. B5 lampiran butuh A7. A2 butuh pipeline final dari B2. A1 dan B1 bisa dikerjakan paralel sejak sekarang.