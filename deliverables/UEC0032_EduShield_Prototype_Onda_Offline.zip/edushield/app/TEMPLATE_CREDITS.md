# Adaptasi Onda untuk EduShield
Sumber: https://github.com/8bsite/design-studio-website-template
Desain asli: 8B, 2026. Lisensi MIT: TEMPLATE_LICENSE.txt.
Palet, proporsi tipografi, titik lingkaran, tombol pil, dan pergantian bidang hitam/putih diadaptasi untuk prototype EduShield.
Orb SVG dibuat secara lokal untuk EduShield. Tidak menggunakan foto Unsplash, data klien demo, formulir kontak, GSAP, atau Lenis dari template asli.
Font lokal menggunakan Arial Black dan Segoe UI; Gabarito/Onest tidak disertakan dalam ZIP dan tidak diperlukan untuk membuka prototype secara offline.
Arsip referensi asli disimpan di ../reference/design-studio/.
