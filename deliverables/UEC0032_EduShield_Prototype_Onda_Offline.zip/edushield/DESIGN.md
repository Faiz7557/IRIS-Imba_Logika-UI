# Spesifikasi dan wireframe yang dibangun

Pengguna utama: analis kuota pusat. Pengguna sekunder: dinas dan admin agregat. K1–K4 memakai default Plan A dalam mandat eksekusi pengguna. Produk adalah prototype kuota agregat, tanpa pemeringkatan siswa.

Tema aktif: adaptasi Onda / 8B dari ZIP design-studio-website-template-main.zip. Referensi asli disimpan di reference/design-studio. Audit dan pemetaan komponen: AUDIT_TEMPLATE_ONDA.md.

Palet: bidang gelap/teks #0D0C11, putih #FFFFFF, aksen #6C3CFF, tautan #6030E8, permukaan #EFEEF4, teks sekunder #5D5A67, garis #DBD9E3. Judul Arial Black dengan cadangan Segoe UI/Arial; isi Segoe UI/Arial. Font lokal menjaga penggunaan offline. Logo perisai memakai violet. Petak memiliki simbol I–IV, kurva memiliki garis putus-putus, bar memiliki label angka. Bukti kontras tema baru: verification/onda/contrast.json (laporan kontras lama di verification/contrast_report.json milik tema v2).

Wireframe desktop:

```text
+-----------------------------------------------------------------------+
| EduShield.     Beranda / Radar / Simulator / Bandingkan   Lembar usulan |
| Data simulasi dan batas interpretasi                                   |
| Ruang kerja   Navigasi lengkap menurut peran                           |
| Breadcrumb                                      Atur ulang skenario   |
+-----------------------------------------------------------------------+
| A1: intro + Terarah + orb violet / ring                                 |
|     ringkasan skenario / analisis / empat langkah / CTA                 |
| A2–L3: judul + panel analisis / kontrol / tabel yang dapat digeser       |
+-----------------------------------------------------------------------+
| Identitas / dokumentasi / versi data dan model / atribusi 8B             |
+-----------------------------------------------------------------------+
```

| Layar | Area keputusan utama | Area penjelasan / aksi |
|---|---|---|
| A1 | Pagu, proksi rentan, manfaat seed 0 | Cakupan gugus, λ, median MC terpisah |
| A2 | Peta petak dan filter | 20 laju tertinggi dan rentang stabilitas |
| A3 | Prediksi dan kuota wilayah | Kontribusi logit, kurva marjinal dan batas |
| A4 | Penggeser pagu, α, β, κ, biaya | Bejana cakupan, tabel 514 hasil, galat input |
| A5 | Perbandingan siswa tertahan | Pemilih proyeksi/evaluasi dan median MC |
| A6 | Heatmap ketidakcocokan asumsi | Ukuran prediksi dan arti gain |
| A7 | Lintasan kuota lima tahun | Manfaat evaluasi dan cakupan per gugus |
| A8 | Tabel usulan kuota kontinu | Catatan peninjau, cetak, CSV, JSON |
| B1 | Merata, KKT dan transisi daerah | Alasan umum dan tautan pemeriksaan |
| B2 | Faktor model wilayah | Kurva marjinal dan daerah serupa |
| B3 | Mockup formulir koreksi | Bukti dan pratinjau tanpa pengiriman |
| B4 | Mockup format laporan agregat | Pemilihan berkas tanpa unggah |
| C1 | Mockup validasi paket | Cakupan 514/38, batas validasi produksi |
| C2 | Mockup kalibrasi | Residual Supiori, κ dan agenda semester |
| C3 | Mockup audit | Antrean contoh dan kebutuhan log override |
| L1 | Identitas visual | Logo, tagline, palet, tipografi |
| L2 | Arsitektur empat lapis | Kontrak paket dan hash |
| L3 | Rencana pilot | Tahapan dan indikator yang belum tercapai |

Pada lebar ≤800 px, tombol Menu membuka navigasi dan pemilih peran; Escape menutupnya dan mengembalikan fokus ke tombol. Pada lebar ≤560 px, panel menjadi satu kolom. Tabel tetap dapat digeser tanpa membuat seluruh halaman melebar. Fokus papan ketik terlihat; tautan lewati navigasi menuju main. Mockup produksi selalu dibedakan dari aksi yang benar-benar bekerja.
