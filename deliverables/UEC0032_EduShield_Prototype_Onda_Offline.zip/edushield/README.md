# EduShield prototype · tema Onda

Buka `app/index.html` langsung di Chrome atau Edge. Tidak memerlukan internet, server, atau instalasi paket antarmuka. Semua angka risiko/manfaat/kuota adalah simulasi; ini demonstrasi kuota kontinu agregat, bukan penetapan penerima.

## Reproduksi

```powershell
python edushield/edushield.py --export
node edushield/test_app.cjs
python edushield/test_kkt.py
python edushield/capture_app.py
```

Jalankan dari folder induk proyek. Dependensi ekspor: numpy, pandas, scipy, statsmodels, scikit-learn. Untuk mengulang seluruh riset: lightgbm dan `python edushield/edushield.py 30`; ini menulis ulang results, kemudian ekspor kembali. Screenshot memakai Python Playwright dan Chrome terpasang. `capture_app.py` memerlukan izin meluncurkan proses Chrome di lingkungan yang membatasi proses anak.

## Peta berkas

`export_app.py` membangun paket dari data BPS lokal dan DGP seed 0; `app/kkt.js` solver murni; `app/app.js` seluruh layar; `app/style.css` gaya dan cetak. `app/data.js` adalah salinan JSON yang dapat dibaca melalui file lokal, bukan data lain. `app_data.sha256` mengidentifikasi paket JSON persis. `verification/` bukti uji; `lampiran/` screenshot dan lembar usulan.

## Batas implementasi

Interaktif: A1–A5, A7–A8, B1–B2. A6 menampilkan eksperimen tersimpan. B3–B4 dan C1–C3 mockup jelas, tanpa layanan unggah atau autentikasi. L1–L3 dokumentasi identitas, arsitektur, dan pilot. Peta petak lengkap tidak bersifat geografis. Versi produksi memerlukan kode BPS resmi, data riil, validasi temporal, tata kelola, pembulatan kuota dan integrasi penetapan penerima.

Pagu simulator adalah porsi dari biaya cakupan penuh pada biaya skenario aktif. Eksperimen kenaikan biaya terpencil di summary penelitian memakai pagu tetap, sehingga angka kedua eksperimen tidak boleh disamakan. Rentang risiko antar-lipatan adalah rentang stabilitas, bukan interval prediksi. κ=1,74 tetap asumsi skenario selama penafsiran studi PIP belum diperiksa pada tabel teks penuh.

Lihat `../ANALISIS_DAN_EKSEKUSI_EduShield.md` untuk keputusan metodologi, perubahan terhadap kedua plan, dan keterbatasan.

## Tema Onda / 8B

Tema dari ZIP pengguna diadaptasi ke seluruh 18 layar. Buka `app/index.html` untuk versi aktif. Beranda menampilkan huruf besar, orb SVG lokal, bidang hitam/putih, aksen violet, dan tombol pil. Seluruh layar analisis memakai token yang sama. Source referensi lengkap ada di `reference/design-studio/`; lisensi distribusi ada di `app/TEMPLATE_LICENSE.txt` dan atribusi di `app/TEMPLATE_CREDITS.md`.

Audit komponen, keputusan adaptasi, dan batas implementasi: `AUDIT_TEMPLATE_ONDA.md`. Tidak ada foto, font, analitik, formulir kontak, atau skrip CDN yang dimuat saat aplikasi dibuka. Font cadangan lokal digunakan karena font asli Gabarito/Onest tidak dibundel dalam ZIP.

Verifikasi browser tema (Node.js, Python Playwright terpasang, dan Chrome):

```powershell
node edushield/test_theme.cjs
```

Laporan dan screenshot terbaru ada di `verification/onda/`. Pengujian lama `capture_app.py` tetap tersedia untuk reproduksi artefak lampiran lama. Cadangan antarmuka sebelum adaptasi ada di `verification/before-onda/`.
